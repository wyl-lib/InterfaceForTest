﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Com.Alipay.Model
{
    /// <summary>
    /// ExtendParams 的摘要说明
    /// </summary>
    public class ExtendParams
    {

        public string sys_service_provider_id { get; set; }

        public ExtendParams()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
    }
}