namespace Aop.Api
{
    /// <summary>
    /// AlipayMobilePublicMultiMediaDownloadResponse.
    /// </summary>
    public class AlipayMobilePublicMultiMediaDownloadResponse : AopResponse
    {
    }
}
